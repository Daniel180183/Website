# Copyright 2004-2026 Tom Rothamel <pytom@bishoujo.us>
#
# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

import collections
import pathlib
import site
import socket
import subprocess
import sys
from typing import TypedDict


class Version:
    def __init__(self, branch: str, semver: tuple[int, int, int], name: str):
        """
        `branch`
            The name of the branch, as a string.

        `semver`
            The Ren'Py version number, a tuple of (major, minor, patch).

        `name`
            The Ren'Py version name.
        """

        self.branch = branch
        self.semver = semver
        self.name = name

        branch_to_version[branch] = self


branch_to_version: dict[str, Version] = {}


Version("main", (8, 7, 0), "TBD")

Version("fix", (8, 6, 1), "Real Artists Ship")


class VersionDict(TypedDict):
    """
    Dictionary that stores all the data about current running version.
    """

    semver: tuple[int, int, int, int]
    "The Ren'Py version number, a tuple of (major, minor, patch, commit)."
    version: str
    "The full version number with suffixes as a string."
    name: str
    "The name of the version."
    branch: str
    "The name of the branch from which this version was made."
    official: bool
    "True if this is an official release."
    nightly: bool
    "True if this is a nightly build."
    dirty: bool
    "True if working tree was dirty when this version was made."


def _make_version_string(
    semver: tuple[int, int, int, int],
    branch: str,
    official: bool,
    nightly: bool,
    dirty: bool,
) -> str:
    major, minor, patch, commit = semver

    suffixes: list[str] = []
    if not official:
        suffixes.append("unofficial")
    elif nightly:
        suffixes.append("nightly")

    if dirty:
        suffixes.append("dirty")

    # Only the part of the branch name after the last slash is used (work/tom/test123 -> test123), as the
    # slashes would otherwise end up in the version string and in file names. The name is empty when git is
    # on a detached HEAD, in which case no branch suffix is added.
    short_branch = branch.rsplit("/", 1)[-1]

    if not official and branch not in {"main", "master"} and short_branch:
        suffixes.append(short_branch)

    version = f"{major}.{minor}.{patch}.{commit:08d}"

    if suffixes:
        version += f"+{'.'.join(suffixes)}"

    return version


def get_vc_version() -> VersionDict | None:
    """
    Return version dict from vc_version.py if it exists or None otherwise.
    """

    # vc_version.py contains:
    # branch - Name of the branch from which this the file was generated.
    # dirty - True if the working tree is dirty.
    # official - True if it were an official build.
    # nightly - True if it were a nightly build.
    # version - Semver as a string.
    # version_name - Name of the version.
    try:
        import renpy.vc_version as vc_version  # type: ignore
    except ImportError:
        return None

    major, minor, patch, commit = vc_version.version.split(".")
    semver = (int(major), int(minor), int(patch), int(commit))
    official = vc_version.official and getattr(site, "renpy_build_official", False)
    dirty = getattr(vc_version, "dirty", False)

    return VersionDict(
        semver=semver,
        version=_make_version_string(
            semver,
            vc_version.branch,
            official,
            vc_version.nightly,
            dirty,
        ),
        name=vc_version.version_name,
        branch=vc_version.branch,
        nightly=vc_version.nightly,
        official=official,
        dirty=dirty,
    )


DIRTY_IGNORED_FILES: frozenset[str] = frozenset(
    {
        "sphinx/source/keywords.py",
        "tutorial/game/keywords.py",
    }
)
"Repository-relative paths whose modification does not make the working tree dirty."


def is_git_dirty() -> bool:
    """
    Return True if the git working tree has changes to files not listed in
    `DIRTY_IGNORED_FILES`. Raises subprocess errors if git fails.
    """

    creationflags = 0
    if sys.platform == "win32":
        creationflags = subprocess.CREATE_NO_WINDOW

    status = subprocess.check_output(
        ["git", "status", "--porcelain", "-z", "--untracked-files=all"],
        encoding="utf-8",
        creationflags=creationflags,
    )

    entries = status.split("\0")
    i = 0

    while i < len(entries):
        entry = entries[i]
        i += 1

        if not entry:
            continue

        paths = [entry[3:]]

        # Renames and copies are followed by the original path.
        if entry[0] in "RC" and i < len(entries):
            paths.append(entries[i])
            i += 1

        if any(path not in DIRTY_IGNORED_FILES for path in paths):
            return True

    return False


def get_git_version(nightly: bool = False) -> VersionDict:
    """
    Return `Version` read from the git repository if it exists or None otherwise.
    """

    def get_output(args: list[str]) -> str:
        creationflags = 0
        if sys.platform == "win32":
            creationflags = subprocess.CREATE_NO_WINDOW

        return subprocess.check_output(args, encoding="utf-8", creationflags=creationflags).strip()

    try:
        git_root = get_output(["git", "rev-parse", "--show-toplevel"])

        root = pathlib.Path(__file__).parent.parent
        if not root.samefile(git_root):
            raise Exception("Current git repository is not Ren'Py repository.")

        branch = get_output(["git", "branch", "--show-current"])
        dirty = is_git_dirty()
        commits = get_output(["git", "log", "-99", "--pretty=%cd", "--date=format:%y%m%d"])

        commits_per_day = collections.Counter[str](commits.split())
        key = max(commits_per_day.keys())
        commit = int(f"{key}{commits_per_day[key]:02d}")

    except Exception:
        import traceback

        traceback.print_exc()
        branch = "unknown"
        dirty = False
        commit = 0

    if branch in branch_to_version:
        version_obj = branch_to_version[branch]
    else:
        version_obj = branch_to_version["main"]

    semver = (*version_obj.semver, commit)
    official = socket.gethostname() == "eileen"

    return VersionDict(
        semver=semver,
        version=_make_version_string(
            semver,
            branch,
            official,
            nightly,
            dirty,
        ),
        name=version_obj.name,
        branch=branch,
        official=official,
        nightly=nightly,
        dirty=dirty,
    )


def get_version() -> VersionDict:
    """
    Return a version dict either from local vc_version or from git.
    """

    if (vc_version := get_vc_version()) is not None:
        return vc_version

    return get_git_version()


def get_release_version():
    """
    Returns the version of the last release. If this is a nightly release, returns the version of the fix branch,
    minus one. (eg, if the fix branch is 8.5.3, returns 8.5.2). Otherwise, returns the version of the main branch,
    without the suffix.

    This is only intended for development use from a git checkout.
    """

    version = get_version()
    version_tuple = tuple(map(int, version["version"].split(".")[:3]))

    if version["nightly"] and version["branch"] == "fix" and version_tuple[2] > 0:
        return "{}.{}.{}".format(version_tuple[0], version_tuple[1], version_tuple[2] - 1)
    else:
        return "{}.{}.{}".format(*version_tuple)


def generate_vc_version(nightly: bool = False) -> VersionDict:
    """
    Generates the vc_version.py file.

    `nightly`
        If true, the nightly flag is set.
    """

    version_dict = get_git_version(nightly)

    vc_version_path = pathlib.Path(__file__).parent / "vc_version.py"

    with vc_version_path.open("w") as f:
        print(f"branch = '{version_dict['branch']}'", file=f)
        if version_dict["dirty"]:
            print("dirty = True", file=f)
        print(f"official = {version_dict['official']}", file=f)
        print(f"nightly = {version_dict['nightly']}", file=f)
        print(f"version = {version_dict['version'].split('+')[0]!r}", file=f)
        print(f"version_name = {version_dict['name']!r}", file=f)

    return version_dict


def main():
    import argparse

    ap = argparse.ArgumentParser()
    ap.add_argument("--nightly", action="store_true", help="Set the nightly flag.")
    args = ap.parse_args()

    generate_vc_version(nightly=args.nightly)


if __name__ == "__main__":
    main()
