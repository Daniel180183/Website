# Copyright 2004-2026 Tom Rothamel <pytom@bishoujo.us>
#
# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

# This file contains support for string translation and string formatting
# operations.

import collections
import functools
import os
import re
import string
import sys

import renpy

update_translations = "RENPY_UPDATE_TRANSLATIONS" in os.environ
flags = frozenset("rstiqulcf!")
formatter = string.Formatter()

SIMPLE_NAME = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]*$")

PARSE_CACHE_SIZE = 512
PARSE_CACHE_MAX_LENGTH = 4096

# A sentinel indicating that a simple name was not found in the scope.
NOT_FOUND = object()


def interpolate(s, scope):
    """
    Formats a string using Ren'Py's formatting rules. Ren'Py uses square
    brackets to denote interpolation, but is otherwise similar to native
    f-strings, with a few caveats and additional conversions available.
    """

    rv = ""

    for lit, expr, conv, fmt in _cached_parse(s):
        if lit:
            rv += lit

        if expr is None:
            continue

        if conv is None:
            conv = ""
        elif not conv:
            raise ValueError("conversion specifier cannot be empty")

        code = expr.strip()

        if not code:
            raise ValueError("expected expression")

        if code[-1] == "=":
            rv += expr
            code = code[:-1]

            if not conv and fmt is None:
                conv = "r"

        if renpy.config.interpolate_exprs:
            value = NOT_FOUND

            # Look up simple names directly, using a single walk of the scope.
            if SIMPLE_NAME.match(code):
                try:
                    value = scope[code]
                except KeyError:
                    pass

            if value is NOT_FOUND:
                try:
                    value = renpy.python.py_eval(code, {}, scope)
                except Exception as e:
                    if renpy.config.interpolate_exprs == "fallback":
                        try:
                            value, _ = formatter.get_field(code, (), scope)
                        except Exception:
                            raise e
                    else:
                        raise

        else:
            value, _ = formatter.get_field(code, (), scope)

        if conv:
            value = convert(value, conv, scope)

        if fmt is None:
            fmt = ""

        rv += format(value, fmt)

    return rv


@functools.lru_cache(maxsize=PARSE_CACHE_SIZE)
def _parse_cached(s):
    # Parse whole string and cache the result. Any syntax errors will be
    # raised immediately.
    return tuple(parse(s))


def _cached_parse(s):
    # Do not cache strings that are too long, as this could pin a lot of memory.
    if len(s) > PARSE_CACHE_MAX_LENGTH:
        return parse(s)

    return _parse_cached(s)


def parse(s):
    """
    Parses s according to Ren'Py string formatting rules. Emits a series
    of (literal, expression, conversion, format) tuples.
    """

    # States for the parse state machine.
    LITERAL = 0
    EXPRESSION = 1
    CONVERSION = 2
    FORMAT = 3

    # Conversion flags that we accept.
    FLAGS = flags

    # Markers and offsets for slicing.
    pos = -1
    size = len(s) + pos
    cut = 0
    mark = 0

    # The depth of brackets we've seen.
    brackets = 0
    parens = 0

    # The parts we've seen.
    lit = ""
    expr = None
    conv = None
    fmt = None

    state = LITERAL

    while pos < size:
        pos += 1
        c = s[pos]

        if state is LITERAL:
            if c == "[":
                lit += s[cut:pos]
                cut = pos + 1

                if c == s[pos + 1 : pos + 2]:
                    pos += 1
                else:
                    state = EXPRESSION

        elif state is EXPRESSION:
            if c == "(":
                parens += 1

            elif c == ")":
                if not parens:
                    break

                parens -= 1

            elif c == '"' or c == "'":
                chars = 1
                found = 0

                if c * 2 == s[pos + 1 : pos + 3]:
                    chars += 2
                    pos += 2

                while pos < size:
                    pos += 1
                    n = s[pos]

                    if n == c:
                        found += 1

                        if found == chars:
                            break

                    else:
                        if n == "\\":
                            pos += 1

                        found = 0

            elif parens:
                pass

            elif c == "[":
                brackets += 1

            elif c == "]":
                if brackets:
                    brackets -= 1
                else:
                    yield lit, s[cut:pos], None, None
                    cut = pos + 1
                    state = LITERAL
                    lit = ""

            elif brackets:
                pass

            elif c == "!":
                if s[pos + 1 : pos + 2] == "=":
                    pos += 1
                else:
                    state = CONVERSION
                    expr = s[cut:pos]
                    cut = pos + 1

            elif c == ":":
                state = FORMAT
                expr = s[cut:pos]
                cut = pos + 1

        elif state is CONVERSION:
            if c == "]":
                yield lit, expr, s[cut:pos], fmt
                cut = pos + 1
                state = LITERAL
                lit = ""
                expr = None
                fmt = None

            elif c == ":":
                state = FORMAT
                conv = s[cut:pos]
                cut = pos + 1

            elif c not in FLAGS:
                if fmt is None:
                    raise ValueError(f"invalid conversion {c!r}")

                state = FORMAT
                pos = cut
                cut = mark

        elif state is FORMAT:
            if c == "]":
                yield lit, expr, conv, s[cut:pos]
                cut = pos + 1
                state = LITERAL
                lit = ""
                expr = None
                conv = None

            elif conv is None and c == "!":
                state = CONVERSION
                fmt = s[cut:pos]
                mark = cut
                cut = pos + 1

    if state is not LITERAL:
        raise Exception(f"String {s!r} ends with an open format operation.")

    if cut <= size:
        lit += s[cut:]

    if lit:
        yield lit, None, None, None


def convert(value, conv, scope):
    conv = set(conv)

    if "r" in conv:
        value = repr(value)
        conv.discard("r")

    elif "s" in conv:
        value = str(value)
        conv.discard("s")

    if not conv:
        return value

    # All conversion symbols below assume we have a string.
    if not isinstance(value, str):
        value = str(value)

    if "t" in conv:
        value = renpy.translation.translate_string(value)

    if "i" in conv:
        try:
            value = interpolate(value, scope)
        except RecursionError:
            raise ValueError(f"Substitution {value!r} refers to itself in a loop.")

    if "f" in conv:
        if renpy.config.say_menu_text_filter is not None:
            value = renpy.config.say_menu_text_filter(value)

        for f in renpy.config.say_menu_text_filters:
            value = f(value)

    if "q" in conv:
        value = value.replace("{", "{{")

    if "u" in conv:
        value = value.upper()

    if "l" in conv:
        value = value.lower()

    if "c" in conv:
        value = value[:1].capitalize() + value[1:]

    return value


def substitute(s, scope=None, force=False, translate=True):
    """
    Performs translation and formatting on `s`, as necessary.

    `scope`
        The scope which is used in formatting, in addition to the default
        store.

    `force`
        Force substitution to occur, even if it's disabled in the config.

    `translate`
        Determines if translation occurs.

    Returns the substituted string, and a flag that is True if substitution
    occurred, or False if no substitution occurred.
    """

    if not isinstance(s, str):
        s = str(s)

    if translate:
        s = renpy.translation.translate_string(s)

    # Substitute.
    if not renpy.config.new_substitutions and not force:
        return s, False

    if "[" not in s:
        return s, False

    old_s = s

    dicts = []

    if scope is not None:
        dicts.append(scope)

    if "store.interpolate" in renpy.python.store_dicts:
        dicts.append(renpy.python.store_dicts["store.interpolate"])

    dicts.append(renpy.store.__dict__)

    if len(dicts) == 1:
        variables = dicts[0]
    else:
        variables = collections.ChainMap(*dicts)

    try:
        s = interpolate(s, variables)
    except Exception:
        if renpy.display.predict.predicting:
            return " ", True
        raise

    return s, (s != old_s)


def ___(s):
    """
    :undocumented: Documented directly in the .rst.

    Translates a string, then performs substitutions on it.
    """

    scope = sys._getframe(1).f_locals

    return substitute(s, scope)[0]
