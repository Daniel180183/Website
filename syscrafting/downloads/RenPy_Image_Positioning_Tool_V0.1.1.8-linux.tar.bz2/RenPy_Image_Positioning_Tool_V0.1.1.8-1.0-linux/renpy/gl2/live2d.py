# Copyright 2004-2026 Tom Rothamel <pytom@bishoujo.us>
#
# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

from typing import Any


import renpy
import renpy.gl2.live2dmotion
import renpy.gl2.live2dphysics
import renpy.gl2.live2dpose
from renpy.gl2.gl2shadercache import register_shader
from renpy.display.core import absolute

try:
    import renpy.gl2.live2dmodel as live2dmodel
except ImportError:
    live2dmodel = None

import sys
import os
import json
import collections
import re
import time

did_onetime_init = False

did_web_init = False

web_is_incompatible = False


def onetime_init():
    global did_onetime_init

    if did_onetime_init:
        return

    if renpy.emscripten:
        if web_is_incompatible:
            raise Exception("This version of Live2D Cubism for Web is not compatible with this version of Ren'Py.")

        if not did_web_init:
            raise Exception(
                "Live2D Cubism for Web was not found. Install it in the Ren'Py launcher and rebuild the game."
            )

        dll = "builtin"
    elif renpy.windows:
        dll = "Live2DCubismCore.dll"
    elif renpy.macintosh:
        dll = "libLive2DCubismCore.dylib"
    elif renpy.ios:
        dll = sys.executable
    else:
        dll = "libLive2DCubismCore.so"

    if dll != "builtin":
        fn = os.path.join(os.path.dirname(sys.executable), dll)
        if os.path.exists(fn):
            dll = fn

    dll = dll.encode("utf-8")

    try:
        if not renpy.gl2.live2dmodel.load(dll):  # type: ignore
            raise Exception("Could not load Live2D. {} was not found.".format(dll))
    except Exception as e:
        e.add_note("Live2D Cubism 5.3 or later is required.")
        raise

    did_onetime_init = True


def web_init():
    """
    Initializes live2d for the web platform.
    """

    global did_web_init
    global web_is_incompatible

    try:
        # We assume we're in /, which is where the web build lives.
        source = open("lib/web/live2dcubismcore.js").read()
    except FileNotFoundError:
        return

    m = re.search(r"var _em_module=(.*)var _em = _em_module\(\);", source, re.DOTALL)
    if not m:
        web_is_incompatible = True
        return

    import emscripten

    emscripten.run_script(m.group(0) + "window.live2d_csm = _em;")

    # Wait for the wasm to be ready.
    for i in range(100):
        emscripten.sleep(25)
        if emscripten.run_script_int("window.live2d_csm.asm ? 1 : 0") == 1:
            break
    else:
        raise Exception("Live2D Cubism for Web did not initialize in time.")

    emscripten.run_script(f"""
window.live2d_csm.ccall("csmInitializeAmountOfMemory", null, ["number"], [{renpy.config.live2d_max_memory}]);
""")

    did_web_init = True


did_init = False


def init():
    """
    Called to initialize Live2D, if needed.
    """

    global did_init

    if did_init:
        return

    if live2dmodel is None:
        raise Exception("Live2D has not been built.")

    onetime_init()

    register_shader(
        "live2d.mask",
        glsl=300,
        variables="""
        uniform sampler2D tex0;
        uniform sampler2D tex1;
        uniform vec2 u_model_size;
        uniform float u_live2d_ppu;
        uniform vec2 u_live2d_offset;
        uniform vec4 u_live2d_mask_bounds;
        in vec4 a_position;
        in vec2 a_tex_coord;
        out vec2 v_tex_coord;
        out vec2 v_mask_coord;
    """,
        vertex_200="""
        v_tex_coord = a_tex_coord;
        v_mask_coord = vec2(
            a_position.x * u_live2d_ppu + u_live2d_offset.x,
            u_live2d_offset.y - a_position.y * u_live2d_ppu) / u_model_size;
        if (u_live2d_mask_bounds.z > 0.0) {
            v_mask_coord = (v_mask_coord - u_live2d_mask_bounds.xy) / u_live2d_mask_bounds.zw;
        }
    """,
        fragment_200="""
        vec2 inside = step(vec2(0.0), v_mask_coord) * step(v_mask_coord, vec2(1.0));
        float mask = texture(tex1, v_mask_coord).a * inside.x * inside.y;
        fragment_color = texture(tex0, v_tex_coord) * mask;
    """,
    )

    register_shader(
        "live2d.inverted_mask",
        glsl=300,
        variables="""
        uniform sampler2D tex0;
        uniform sampler2D tex1;
        uniform vec2 u_model_size;
        uniform float u_live2d_ppu;
        uniform vec2 u_live2d_offset;
        uniform vec4 u_live2d_mask_bounds;
        in vec4 a_position;
        in vec2 a_tex_coord;
        out vec2 v_tex_coord;
        out vec2 v_mask_coord;
    """,
        vertex_200="""
        v_tex_coord = a_tex_coord;
        v_mask_coord = vec2(
            a_position.x * u_live2d_ppu + u_live2d_offset.x,
            u_live2d_offset.y - a_position.y * u_live2d_ppu) / u_model_size;
        if (u_live2d_mask_bounds.z > 0.0) {
            v_mask_coord = (v_mask_coord - u_live2d_mask_bounds.xy) / u_live2d_mask_bounds.zw;
        }
    """,
        fragment_200="""
        vec2 inside = step(vec2(0.0), v_mask_coord) * step(v_mask_coord, vec2(1.0));
        float mask = texture(tex1, v_mask_coord).a * inside.x * inside.y;
        fragment_color = texture(tex0, v_tex_coord) * (1.0 - mask);
    """,
    )

    register_shader(
        "live2d.colors",
        glsl=300,
        variables="""
        uniform vec4 u_multiply;
        uniform vec4 u_screen;
    """,
        fragment_250="""
        fragment_color.rgb *= u_multiply.rgb;
        fragment_color.rgb += u_screen.rgb * (fragment_color.a - fragment_color.rgb);
    """,
    )

    register_shader(
        "live2d.flip_texture",
        glsl=300,
        variables="""
        out vec2 v_tex_coord;
    """,
        vertex_250="""
        v_tex_coord.y = 1.0 - v_tex_coord.y;
    """,
    )

    # Implements the Cubism 5.3 color and alpha blend modes. This takes the
    # premultiplied color computed by the shaders before it, and blends it with
    # the backdrop - a texture containing what has been drawn beneath it. The
    # result replaces what is in the framebuffer, so this must be used with a
    # blend_func that replaces the destination. The mode uniforms use the
    # values of csmColorBlendType and csmAlphaBlendType.
    register_shader(
        "live2d.blend",
        glsl=300,
        variables="""
        uniform sampler2D u_live2d_backdrop;
        uniform int u_live2d_color_blend;
        uniform int u_live2d_alpha_blend;
        uniform vec2 u_model_size;
        uniform float u_live2d_ppu;
        uniform vec2 u_live2d_offset;
        in vec4 a_position;
        out vec2 v_live2d_backdrop_coord;
    """,
        fragment_functions="""
        vec4 live2d_straight(vec4 c) {
            if (abs(c.a) < 1e-5) {
                return vec4(0.0, 0.0, 0.0, c.a);
            }

            return vec4(c.rgb / c.a, c.a);
        }

        float live2d_luma(vec3 c) {
            return dot(c, vec3(0.30, 0.59, 0.11));
        }

        vec3 live2d_clip_color(vec3 c) {
            float l = live2d_luma(c);
            float n = min(min(c.r, c.g), c.b);
            float x = max(max(c.r, c.g), c.b);

            if (n < 0.0) {
                c = l + (c - l) * l / (l - n);
            }

            if (x > 1.0) {
                c = l + (c - l) * (1.0 - l) / (x - l);
            }

            return c;
        }

        vec3 live2d_set_luma(vec3 c, float l) {
            return live2d_clip_color(c + (l - live2d_luma(c)));
        }

        vec3 live2d_set_saturation(vec3 c, float s) {
            float n = min(min(c.r, c.g), c.b);
            float x = max(max(c.r, c.g), c.b);

            if (x <= n) {
                return vec3(0.0);
            }

            return (c - n) * s / (x - n);
        }

        float live2d_color_burn(float s, float d) {
            if (abs(d - 1.0) < 1e-6) {
                return 1.0;
            } else if (abs(s) < 1e-6) {
                return 0.0;
            }

            return 1.0 - min(1.0, (1.0 - d) / s);
        }

        float live2d_color_dodge(float s, float d) {
            if (d <= 0.0) {
                return 0.0;
            } else if (s >= 1.0) {
                return 1.0;
            }

            return min(1.0, d / (1.0 - s));
        }

        float live2d_hard_light(float s, float d) {
            if (s < 0.5) {
                return 2.0 * s * d;
            }

            return 1.0 - 2.0 * (1.0 - s) * (1.0 - d);
        }

        float live2d_soft_light(float s, float d) {
            if (s <= 0.5) {
                return d - (1.0 - 2.0 * s) * d * (1.0 - d);
            } else if (d <= 0.25) {
                return d + (2.0 * s - 1.0) * d * ((16.0 * d - 12.0) * d + 3.0);
            }

            return d + (2.0 * s - 1.0) * (sqrt(d) - d);
        }

        float live2d_linear_light(float s, float d) {
            if (s < 0.5) {
                return max(0.0, 2.0 * s + d - 1.0);
            }

            return min(1.0, 2.0 * (s - 0.5) + d);
        }

        vec3 live2d_color_blend(vec3 s, vec3 d, int mode) {
            if (mode == 3) {
                return min(s + d, 1.0);
            } else if (mode == 4) {
                return s + d;
            } else if (mode == 5) {
                return min(s, d);
            } else if (mode == 6) {
                return s * d;
            } else if (mode == 7) {
                return vec3(live2d_color_burn(s.r, d.r), live2d_color_burn(s.g, d.g), live2d_color_burn(s.b, d.b));
            } else if (mode == 8) {
                return max(s + d - 1.0, 0.0);
            } else if (mode == 9) {
                return max(s, d);
            } else if (mode == 10) {
                return s + d - s * d;
            } else if (mode == 11) {
                return vec3(live2d_color_dodge(s.r, d.r), live2d_color_dodge(s.g, d.g), live2d_color_dodge(s.b, d.b));
            } else if (mode == 12) {
                return vec3(live2d_hard_light(d.r, s.r), live2d_hard_light(d.g, s.g), live2d_hard_light(d.b, s.b));
            } else if (mode == 13) {
                return vec3(live2d_soft_light(s.r, d.r), live2d_soft_light(s.g, d.g), live2d_soft_light(s.b, d.b));
            } else if (mode == 14) {
                return vec3(live2d_hard_light(s.r, d.r), live2d_hard_light(s.g, d.g), live2d_hard_light(s.b, d.b));
            } else if (mode == 15) {
                return vec3(live2d_linear_light(s.r, d.r), live2d_linear_light(s.g, d.g), live2d_linear_light(s.b, d.b));
            } else if (mode == 16) {
                float sd = max(max(d.r, d.g), d.b) - min(min(d.r, d.g), d.b);
                return live2d_set_luma(live2d_set_saturation(s, sd), live2d_luma(d));
            } else if (mode == 17) {
                return live2d_set_luma(s, live2d_luma(d));
            }

            return s;
        }

        vec4 live2d_alpha_blend(vec3 c, vec4 s, vec4 d, int mode) {
            vec3 p;

            if (mode == 1) {
                p = vec3(s.a * d.a, 0.0, d.a * (1.0 - s.a));
            } else if (mode == 2) {
                p = vec3(0.0, 0.0, d.a * (1.0 - s.a));
            } else if (mode == 3) {
                p = vec3(min(s.a, d.a), max(s.a - d.a, 0.0), max(d.a - s.a, 0.0));
            } else if (mode == 4) {
                p = vec3(max(s.a + d.a - 1.0, 0.0), min(s.a, 1.0 - d.a), min(d.a, 1.0 - s.a));
            } else {
                p = vec3(s.a * d.a, s.a * (1.0 - d.a), d.a * (1.0 - s.a));
            }

            return vec4(c * p.x + s.rgb * p.y + d.rgb * p.z, p.x + p.y + p.z);
        }
    """,
        vertex_300="""
        v_live2d_backdrop_coord = vec2(
            a_position.x * u_live2d_ppu + u_live2d_offset.x,
            u_live2d_offset.y - a_position.y * u_live2d_ppu) / u_model_size;
    """,
        fragment_700="""
        vec4 live2d_src = live2d_straight(fragment_color);
        vec4 live2d_dst = live2d_straight(texture(u_live2d_backdrop, v_live2d_backdrop_coord));
        fragment_color = live2d_alpha_blend(
            live2d_color_blend(live2d_src.rgb, live2d_dst.rgb, u_live2d_color_blend),
            live2d_src, live2d_dst, u_live2d_alpha_blend);
    """,
    )

    did_init = True


def reset():
    """
    Resets this module when Ren'Py reloads the script.
    """

    global did_init
    did_init = False

    common_cache.clear()


def reset_states():
    """
    Resets the Live2D states when Ren'Py restarts the game.
    """

    states.clear()


def reset_pose_states() -> None:
    """
    Resets unsaved pose selections after loading, without changing motion or
    expression state.
    """

    for state in states.values():
        state.pose_sustained.clear()
        state.pose_opacities = None
        state.pose_time = 0.0


class Live2DExpression(object):
    """
    The data corresponding to an expression.
    """

    def __init__(self, parameters, fadein, fadeout):
        self.parameters = parameters
        self.fadein = fadein
        self.fadeout = fadeout


class Live2DCommon(object):
    """
    This object stores information that is common to all of the Live2D
    displayables that use the same .model3.json file, so this information
    only needs to be loaded once. This should not leak into the save games,
    but is loaded at init time.
    """

    def __init__(self, filename, default_fade, old_beziers):
        init()

        if old_beziers is None:
            old_beziers = renpy.config.live2d_old_beziers

        if renpy.config.log_live2d_loading:
            renpy.display.log.write("Loading Live2D from %r.", filename)

        if not renpy.loader.loadable(filename, directory="images"):
            raise Exception("Live2D model {} does not exist.".format(filename))

        # A short name for the model.
        model_name = filename.rpartition("/")[2].partition(".")[0].lower()

        # The path to where the files used are stored.
        self.base = filename.rpartition("/")[0]

        if self.base:
            self.base += "/"

        # The contents of the .model3.json file.
        with renpy.loader.load(filename, directory="images") as f:
            self.model_json = json.load(f)

        # The model created from the moc3 file.
        self.model = renpy.gl2.live2dmodel.Live2DModel(  # type: ignore
            self.base + self.model_json["FileReferences"]["Moc"]
        )
        
        self.physics = renpy.gl2.live2dphysics.load_physics(
            self.model, self.base, self.model_json["FileReferences"].get("Physics")
        )

        # The pose, which is loaded when first used by get_pose.
        self.pose = None  # type: renpy.gl2.live2dpose.Pose|None
        self.pose_loaded = False

        # A map from part id to the value motions and expressions requested
        # for that part during the current render.
        self.pose_requests = {}  # type: dict[str, float]

        # Pose selector parameters requested by motions, as (remaining weight,
        # weighted value) pairs. Part opacity curves take precedence over these.
        self.pose_parameters: dict[str, tuple[float, float]] = {}

        # The texture images.
        self.textures = []

        for i in self.model_json["FileReferences"]["Textures"]:
            m = re.search(r"\.(\d+)/", i)
            if m:
                size = int(m.group(1))
                renpy.config.max_texture_size = (
                    max(renpy.config.max_texture_size[0], size),
                    max(renpy.config.max_texture_size[1], size),
                )

            im = renpy.easy.displayable(self.base + i)
            im = renpy.display.im.unoptimized_texture(im)
            self.textures.append(im)

        # A map from the motion file name to the information about it.
        motion_files = {}

        # A map from the expression name to the information about it.
        expression_files = {}

        for i in renpy.exports.list_files():
            if not i.startswith(self.base):
                continue

            if i.endswith("motion3.json"):
                i = i[len(self.base) :]
                motion_files[i] = {"File": i}
            elif i.endswith(".exp3.json"):
                i = i[len(self.base) :]
                expression_files[i] = {"File": i}

        def walk_json_files(o, d):
            if isinstance(o, list):
                for i in o:
                    walk_json_files(i, d)
                return

            if "File" in o:
                d[o["File"]] = o
                return

            for i in o.values():
                walk_json_files(i, d)

        walk_json_files(self.model_json["FileReferences"].get("Motions", {}), motion_files)
        walk_json_files(self.model_json["FileReferences"].get("Expressions", {}), expression_files)

        # A list of attributes that are known.
        self.attributes = set(["still", "null"])

        # A map from a motion name to a motion identifier.
        self.motions = {"still": renpy.gl2.live2dmotion.NullMotion()}  # type: dict[str, renpy.gl2.live2dmotion.Motion|renpy.gl2.live2dmotion.NullMotion]

        for i in motion_files.values():
            name = i["File"].lower().rpartition("/")[2].partition(".")[0]

            prefix, _, suffix = name.partition("_")

            if prefix == model_name:
                name = suffix

            if renpy.loader.loadable(self.base + i["File"], directory="images"):
                if renpy.config.log_live2d_loading:
                    renpy.display.log.write(" - motion %s -> %s", name, i["File"])

                self.motions[name] = renpy.gl2.live2dmotion.Motion(
                    self.base + i["File"],
                    i.get("FadeInTime", default_fade),
                    i.get("FadeOutTime", default_fade),
                    old_beziers,
                )

                self.attributes.add(name)

        # A map from an expression to a Live2DExpression object.
        self.expressions = {"null": Live2DExpression([], 0.0, 0.0)}

        for i in expression_files.values():
            name = i["File"].lower().rpartition("/")[2].partition(".")[0]

            prefix, _, suffix = name.partition("_")

            if prefix == model_name:
                name = suffix

            if renpy.loader.loadable(self.base + i["File"], directory="images"):
                if renpy.config.log_live2d_loading:
                    renpy.display.log.write(" - expression %s -> %s", name, i["File"])

                if name in self.attributes:
                    raise Exception("Name {!r} is already specified as a motion.".format(name))

                with renpy.loader.load(self.base + i["File"], directory="images") as f:
                    expression_json = json.load(f)

                self.expressions[name] = Live2DExpression(
                    expression_json.get("Parameters", []),
                    expression_json.get("FadeInTime", default_fade),
                    expression_json.get("FadeOutTime", default_fade),
                )

                self.attributes.add(name)

        for i in self.model_json.get("Groups", []):
            name = i["Name"]
            ids = i["Ids"]

            if i["Target"] == "Parameter":
                self.model.parameter_groups[name] = ids
            elif i["Target"] == "Opacity":
                self.model.opacity_groups[name] = ids

        # All expressions, non-exclusive and exclusive, and its aliases.
        self.all_expressions = dict(self.expressions)

        # Nonexcusive expressions.
        self.nonexclusive = {}  # type: dict[str, Live2DExpression]

        # This may be True, False, or a set of motion names.
        self.seamless = False  # type: bool|set[str]

        # If not None, a function that takes a tuple of attributes, and returns
        # a tuple of attributes.
        self.attribute_function = None  # type: Any

        # Same.
        self.attribute_filter = None  # type: Any

        # If not None, a function that can blend parameters itself after applying expressions.
        self.update_function = None  # type: Any

    def __reduce__(self):
        raise Exception("Live2DCommon objects cannot be pickled.")

    def get_pose(self):
        """
        Returns the model's pose, or None if it doesn't have one. The file is
        loaded here so that it isn't used unless pose support is enabled.
        """

        if not self.pose_loaded:
            self.pose = renpy.gl2.live2dpose.load_pose(
                self.model, self.base, self.model_json["FileReferences"].get("Pose")
            )
            self.pose_loaded = True

        return self.pose

    def apply_aliases(self, aliases):
        for k, v in aliases.items():
            target = None
            expression = False

            if v in self.motions:
                target = self.motions

            elif v in self.expressions:
                target = self.expressions
                expression = True

            elif v in self.nonexclusive:
                target = self.nonexclusive
                expression = True

            else:
                raise Exception("Name {!r} is not a known motion or expression.".format(v))

            if k in target:
                raise Exception("Name {!r} is already specified as a motion or expression.".format(k))

            target[k] = target[v]  # type: ignore

            if expression:
                self.all_expressions[k] = target[v]  # type: ignore

    def apply_nonexclusive(self, nonexclusive):
        for i in nonexclusive:
            if i not in self.expressions:
                raise Exception("Name {!r} is not a known expression.".format(i))

            self.nonexclusive[i] = self.expressions.pop(i)

    def apply_seamless(self, value):
        self.seamless = value

    def is_seamless(self, motion):
        if self.seamless is True:
            return True
        elif self.seamless is False:
            return False
        else:
            return motion in self.seamless


# This maps a filename to a Live2DCommon object.
common_cache = {}


class Live2DState(object):
    def __init__(self):
        # Used to mark this state as having been seen in the current
        # iteration.
        self.mark = False

        # Should we cycle new into old?
        self.cycle_new = False

        # The displayable in the old and new state. Both can be None if
        # it's not being shown.
        self.old = None  # type: Live2D|None
        self.new = None  # type: Live2D|None

        # The time at which the old and new displayables were last updated.
        self.old_base_time = 0  # type: float|None
        self.new_base_time = 0  # type: float|None

        # A list of (expression_name, time_shown) tuples.
        self.expressions = []

        # A list of (expression_name, time_shown, time_hidden) tuples.
        self.old_expressions = []

        # A map from pose group index to the id of the selected part.
        self.pose_sustained = {}  # type: dict[int, str]

        # A map from part id to the opacity given to it by the pose, or None
        # if the pose hasn't been applied yet.
        self.pose_opacities = None  # type: dict[str, float]|None

        # The time at which the pose was last applied.
        self.pose_time = 0.0

    def update_expressions(self, expressions, now):
        """
        Updates the lists of new and old expressions.

        `expressions`
            A list of strings giving expression names.

        `now`
            The time the current displayable started showing.
        """

        current = set(name for name, _ in self.expressions)

        self.old_expressions = [
            (name, shown, hidden) for name, shown, hidden in self.old_expressions if name not in expressions
        ] + [(name, shown, now) for name, shown in self.expressions if name not in expressions]

        self.expressions = [(name, shown) for (name, shown) in self.expressions if name in expressions]
        self.expressions += [(name, now) for name in expressions if name not in current]


# A map from name to Live2DState object.
states = collections.defaultdict(Live2DState)

live2d_showing = False
"Is live2d showing in the current interaction?"


def update_states():
    """
    Called once per interact to walk the tree of displayables and find
    the old and new live2d states.
    """

    global live2d_showing

    if not did_init:
        return

    if not live2d_showing:
        return

    live2d_showing = False

    def visit(d):
        nonlocal count

        if not isinstance(d, Live2D):
            return

        assert tag is not None

        index = count[d.filename]
        count[d.filename] = index + 1

        d.name = (layer, tag, d.filename, index)

        state = states[d.name]

        if state.mark:
            return

        state.mark = True

        if state.new is d:
            return

        # Shouldn't happen, but stop thrashing if it does.
        if state.old is d:
            return

        # Deal with the case of two different Live2D displayables being shown
        # with the same layer/tag/name.
        if state.old is not None and state.new is not None:
            if state.old.filename != state.new.filename:
                state.old = None

        if state.cycle_new:
            state.old = state.new
            state.old_base_time = state.new_base_time
        else:
            state.old = None
            state.old_base_time = None
            state.expressions = []
            state.old_expressions = []

        state.new = d

        if d.sustain:
            state.new_base_time = state.old_base_time
        else:
            state.new_base_time = None

        state.cycle_new = True

    sls = renpy.display.scenelists.scene_lists()

    count = collections.defaultdict(int)

    for layer, tag, d in sls.get_all_layer_tag_displayable():
        if tag is None:
            continue

        if "$" in tag:
            continue

        count.clear()

        if d is not None:
            d.visit_all(visit)

    for s in states.values():
        if not s.mark:
            s.cycle_new = False

        s.mark = False


def expand_filename(filename: str) -> str:
    """
    Returns the path to the .model3.json file for a Live2D `filename`, which may name either that file or a
    directory containing <directory name>.model3.json.
    """

    if filename.endswith(".json"):
        return filename

    suffix = filename.rpartition("/")[2]
    return f"{filename}/{suffix}.model3.json"


class Live2D(renpy.display.displayable.Displayable):
    name: tuple[str, str, str, int] | None = None
    """
    A structural name for this displayable, consisting of the layer, tag, and a count. This is used to
    match the displayable to its state in a previous interaction.
    """

    __version__ = 1

    def after_upgrade(self, version):
        # Before version 1, a directory given as the filename was kept as is, and expanded by Live2DCommon.
        if version < 1:
            self.filename = expand_filename(self.filename)

    nosave = ["common_cache"]

    common_cache: Live2DCommon | None = None

    _duplicatable = True
    used_nonexclusive = None
    properties = {}

    filename: str
    "Path to the .model3.json file that describes this Live2D model."

    default_fade: float = 1.0
    "Fade time to use for motions that don't specify a fade time."

    old_beziers: bool | None = None
    """
    If True, this uses the old Bezier curve behavior, which uses easing.
    If False, the Cardano interpretation of beziers is used.
    If none, the value of config.live2d_old_beziers is used.
    """

    pose: bool | None = None
    """
    If True, the model's pose file is used. If False, it's ignored. If None,
    the value of config.live2d_pose is used.
    """

    deduplication_key: str | None = None
    """
    A key used to deduplicate Live2D displayables together with filename
    and default_fade. This can be used to have same Live2D displayables
    with different set of aliases, and other properties.
    """

    @property
    def common(self) -> Live2DCommon:
        if self.common_cache is not None:
            return self.common_cache

        key = (
            self.filename,
            self.default_fade,
            self.old_beziers,
            self.deduplication_key,
        )

        # Look in global cache.
        if (rv := common_cache.get(key)) is None:
            rv = common_cache[key] = Live2DCommon(
                self.filename,
                self.default_fade,
                self.old_beziers,
            )

        # Cache on instance.
        self.common_cache = rv
        return rv

    # Note: When adding new parameters, make sure to add them to _duplicate, too.
    def __init__(
        self,
        filename: str,
        zoom=None,
        top=0.0,
        base=1.0,
        height=1.0,
        loop=False,
        aliases=None,
        fade=None,
        motions=None,
        expression=None,
        nonexclusive=None,
        used_nonexclusive=None,
        seamless=None,
        sustain=False,
        attribute_function=None,
        attribute_filter=None,
        update_function=None,
        default_fade: float = 1.0,
        old_beziers: bool | None = None,
        deduplication_key: str | None = None,
        pose: bool | None = None,
        **properties,
    ):
        super().__init__(**properties)

        self.motions = motions
        self.expression = expression
        self.used_nonexclusive = used_nonexclusive  # type: list[str]|None

        self.zoom = zoom
        self.top = top
        self.base = base
        self.height = height
        self.loop = loop
        self.fade = fade
        self.sustain = sustain

        # The name of this displayable.
        self.name = None

        self.properties = properties

        # Should be set before call to self.common.
        self.filename = expand_filename(filename)
        self.default_fade = default_fade
        self.old_beziers = old_beziers
        self.deduplication_key = deduplication_key
        self.pose = pose

        # Load the common data. Needed!
        common = self.common

        if nonexclusive:
            common.apply_nonexclusive(nonexclusive)

        if aliases:
            common.apply_aliases(aliases)

        if seamless is not None:
            common.apply_seamless(seamless)

        if attribute_function is not None:
            common.attribute_function = attribute_function

        if attribute_filter is not None:
            common.attribute_filter = attribute_filter

        if update_function is not None:
            common.update_function = update_function

    # Used to assign unique names to Live2D objects.
    unique_time = str(int(time.time()))
    unique_serial = 0

    def ensure_name(self):
        """
        Ensures a unique name is assigned to this live2d object, if None is given.
        """

        if self.name is not None:
            return

        self.name = ("_unique", self.unique_time, "", self.unique_serial)
        Live2D.unique_serial += 1

    def per_interact(self):
        global live2d_showing
        live2d_showing = True

    def _duplicate(self, args):
        if not self._duplicatable:
            return self

        if not args:
            return self

        common = self.common
        motions = []
        used_nonexclusive = []

        expression = None
        sustain = False

        if "_sustain" in args.args:
            attributes = tuple(i for i in args.args if i != "_sustain")
            sustain = True
        else:
            attributes = args.args

        if common.attribute_filter:
            attributes = common.attribute_filter(attributes)
            if not isinstance(attributes, tuple):
                attributes = tuple(attributes)

        if common.attribute_function is not None:
            attributes = common.attribute_function(attributes)

        for i in attributes:
            if i in common.motions:
                motions.append(i)
                continue

            if i in common.nonexclusive:
                used_nonexclusive.append(i)
                continue

            if i in common.expressions:
                if expression is not None:
                    raise Exception(
                        "When showing {}, {} and {} are both live2d expressions.".format(
                            " ".join(args.name), i, expression
                        )
                    )

                expression = i
                continue

            raise Exception("When showing {}, {} is not a known attribute.".format(" ".join(args.name), i))

        rv = Live2D(
            self.filename,
            motions=motions,
            zoom=self.zoom,
            top=self.top,
            base=self.base,
            height=self.height,
            loop=self.loop,
            fade=self.fade,
            expression=expression,
            used_nonexclusive=used_nonexclusive,
            sustain=sustain,
            default_fade=self.default_fade,
            old_beziers=self.old_beziers,
            deduplication_key=self.deduplication_key,
            pose=self.pose,
            **self.properties,
        )

        rv._duplicatable = False

        return rv

    def _list_attributes(self, tag, attributes):
        common = self.common

        available = set(common.attributes)

        for i in attributes:
            if i in common.expressions:
                available -= set(common.expressions)

        available |= set(attributes)

        return [i for i in common.attributes if i in available]

    def _choose_attributes(self, tag, attributes, optional):
        # Filter out _sustain.
        attributes = [i for i in attributes if i != "_sustain"]

        common = self.common

        # Chose all motions.
        rv = [i for i in attributes if i in common.motions]

        # Choose the first expression.
        for i in list(attributes) + list(optional):
            if i in common.expressions:
                rv.insert(0, i)
                break

        # Choose all possible nonexclusive attributes.
        for i in sorted(list(attributes)):
            if i in common.nonexclusive:
                rv.append(i)

        for i in sorted(list(optional)):
            if i in common.nonexclusive:
                rv.append(i)

        if set(attributes) - set(rv):
            return None

        rv = tuple(rv)

        if common.attribute_filter:
            rv = common.attribute_filter(rv)
            if not isinstance(rv, tuple):
                rv = tuple(rv)

        # If there are no motions, take the optional motions and sustain those.
        if not any(i in common.motions for i in rv):
            rv = ("_sustain",) + tuple(i for i in optional if i in common.motions) + rv

        return rv

    def update(self, common, st, st_fade):
        """
        This updates the common model with the information taken from the
        motions associated with this object. It returns the delay until
        Ren'Py needs to cause a redraw to occur, or None if no delay
        should occur.
        """

        if not self.motions:
            return

        # True if the motion should be faded in.
        do_fade_in = True

        # True if the motion should be faded out.
        do_fade_out = True

        # True if this is the last frame of a series of motions.
        last_frame = False

        # The index of the current motion in self.motions.
        current_index = 0

        # The motion object to display.
        motion = None

        # Determine the current motion.

        motion_st = st

        if st_fade is not None:
            motion_st = st - st_fade

        for m in self.motions:
            motion = common.motions.get(m, None)

            if motion is None:
                continue

            if motion.duration > st:
                break

            elif (motion.duration > motion_st) and not common.is_seamless(m):
                break

            motion_st -= motion.duration
            st -= motion.duration
            current_index += 1

        else:
            if motion is None:
                return None

            m = self.motions[-1]

            if (not self.loop) or (not motion.duration):
                st = motion.duration
                last_frame = True

            elif (st_fade is not None) and not common.is_seamless(m):
                # This keeps a motion from being restarted after it would have
                # been faded out.
                motion_start = motion_st - motion_st % motion.duration

                if (st - motion_start) > motion.duration:
                    st = motion.duration
                    last_frame = True

        if motion is None:
            return None

        # Determine the name of the current, last, and next motions. These are
        # None if there is no motion.

        if current_index < len(self.motions):
            current_name = self.motions[current_index]
        else:
            current_name = self.motions[-1]

        if current_index > 0:
            last_name = self.motions[current_index - 1]
        else:
            last_name = None

        if current_index < len(self.motions) - 1:
            next_name = self.motions[current_index + 1]
        elif self.loop:
            next_name = self.motions[-1]
        else:
            next_name = None

        # Handle seamless.

        if (last_name == current_name) and common.is_seamless(current_name):
            do_fade_in = False

        if (next_name == current_name) and common.is_seamless(current_name) and (st_fade is None):
            do_fade_out = False

        # Apply the motion.

        motion_data = motion.get(st, st_fade, do_fade_in, do_fade_out)
        pose = self.get_pose()

        for k, v in motion_data.items():
            kind, key = k
            factor, value = v

            if kind == "PartOpacity":
                common.model.set_part_opacity(key, value)
                common.pose_requests.setdefault(key, value)
            elif kind == "Parameter":
                common.model.set_parameter(key, value, factor)

                if pose is not None and key in pose.part_groups:
                    remaining, total = common.pose_parameters.get(key, (1.0, 0.0))
                    weight = min(factor, remaining)
                    common.pose_parameters[key] = (remaining - weight, total + weight * value)

            elif kind == "Model":
                common.model.set_parameter(key, value, factor)

        if last_frame:
            return None
        else:
            return motion.wait(st, st_fade, do_fade_in, do_fade_out)

    def update_expressions(self, st):
        self.ensure_name()

        common = self.common
        model = common.model
        state = states[self.name]

        now = renpy.display.interface.frame_time

        # Reap obsolete old_expressions.
        state.old_expressions = [
            (name, shown, hidden)
            for (name, shown, hidden) in state.old_expressions
            if (now - hidden) < common.all_expressions[name].fadeout
        ]

        # Determine the list of expressions that are being shown by this displayable.
        if self.used_nonexclusive is None:
            expressions = []
        else:
            expressions = list(self.used_nonexclusive)  # type: ignore

        if self.expression:
            expressions.append(self.expression)

        # Use them to update old_expressions and expressions in the frame.
        state.update_expressions(expressions, now - st)

        pose = self.get_pose()

        if pose is not None:
            for part_id, (remaining, value) in common.pose_parameters.items():
                group_index = pose.part_groups[part_id]
                sustained = state.pose_sustained.get(group_index, pose.groups[group_index][0].part_id)
                default = 1.0 if part_id == sustained else 0.0
                common.pose_requests.setdefault(part_id, value + remaining * default)

        # Actually blend.
        redraw = None

        for name, shown, hidden in state.old_expressions:
            weight = 1.0
            e = common.all_expressions[name]

            if now - hidden >= e.fadeout:
                continue

            if (e.fadein > 0) and (now - shown) < e.fadein:
                weight = min(weight, (now - shown) / e.fadein)
                redraw = 0

            if (e.fadeout > 0) and (now - hidden) < e.fadeout:
                weight = min(weight, 1.0 - (now - hidden) / e.fadeout)
                redraw = 0

            for i in e.parameters:
                model.blend_parameter(i["Id"], i["Blend"], i["Value"], weight=weight)

                if pose is not None:
                    pose.blend_request(common.pose_requests, state.pose_sustained, i, weight)

        for name, shown in state.expressions:
            weight = 1.0
            e = common.all_expressions[name]

            if (e.fadein > 0) and (now - shown) < e.fadein:
                weight = min(weight, (now - shown) / e.fadein)
                redraw = 0

            for i in e.parameters:
                model.blend_parameter(i["Id"], i["Blend"], i["Value"], weight=weight)

                if pose is not None:
                    pose.blend_request(common.pose_requests, state.pose_sustained, i, weight)

        return redraw

    def get_pose(self):
        """
        Returns the pose this displayable should apply, or None if it shouldn't
        apply one.
        """

        enabled = self.pose if self.pose is not None else renpy.config.live2d_pose

        return self.common.get_pose() if enabled else None

    def update_pose(self):
        """
        Selects a part from each pose group, and applies the resulting opacities
        to the model. This returns the time until the next redraw, or None if
        no redraw is required.
        """

        pose = self.get_pose()

        if pose is None:
            return None

        common = self.common
        state = states[self.name]
        now = renpy.display.interface.frame_time

        # The first time, parts start out at their final opacity.
        if state.pose_opacities is None:
            state.pose_opacities = {}
            dt = pose.fade_time
            fade_time = 0.0
        else:
            dt = now - state.pose_time
            fade_time = pose.fade_time

        state.pose_time = now

        redraw = None

        for index, group in enumerate(pose.groups):
            sustained = state.pose_sustained.get(index)
            visible = renpy.gl2.live2dpose.select_part(group, common.pose_requests, sustained)
            state.pose_sustained[index] = visible

            # A new fade starts now, even if the previous render was long ago.
            group_dt = dt if visible == sustained else 0.0

            if renpy.gl2.live2dpose.fade_group(group, visible, state.pose_opacities, group_dt, fade_time):
                redraw = 0

        for part_id, opacity in state.pose_opacities.items():
            common.model.blend_opacity(part_id, "Overwrite", opacity)

        return redraw

    def blend_parameter(self, name, blend, value, weight=1.0):
        if blend not in ("Add", "Multiply", "Overwrite"):
            raise Exception("Unknown blend mode {!r}".format(blend))

        self.common.model.blend_parameter(name, blend, value, weight)

    def blend_opacity(self, name, blend, value, weight=1.0):
        if blend not in ("Add", "Multiply", "Overwrite"):
            raise Exception("Unknown blend mode {!r}".format(blend))

        self.common.model.blend_opacity(name, blend, value, weight)

    def render(self, width, height, st, at):
        self.ensure_name()

        common = self.common
        model = common.model

        # Determine if we should fade.
        fade = self.fade if (self.fade is not None) else renpy.store._live2d_fade

        if not self.name:
            fade = False

        if fade:
            state = states[self.name]

            if state.new is not self:
                fade = False

            if state.new_base_time is None:
                state.new_base_time = renpy.display.interface.frame_time - st

            if state.old is None:
                fade = False
            elif state.old_base_time is None:
                fade = False
            elif state.old.common is not self.common:
                fade = False

        # Reset the parameter, and update.
        model.reset_parameters()
        common.pose_requests.clear()
        common.pose_parameters.clear()

        if fade:
            t = renpy.display.interface.frame_time - state.new_base_time  # type: ignore
        else:
            t = st

        new_redraw = self.update(common, t, None)

        if fade:
            old_redraw = state.old.update(common, renpy.display.interface.frame_time - state.old_base_time, st)  # type: ignore
        else:
            old_redraw = None

        model.finish_parameters()

        # Apply the expressions.
        expression_redraw = self.update_expressions(st)

        # Apply the pose. This is before the user-defined update, so that can override it.
        pose_redraw = self.update_pose()

        # Apply the user-defined update.
        if common.update_function is None:
            user_redraw = None
        else:
            user_redraw = common.update_function(self, st)

        physics_redraw = None

        if common.physics is not None:
            physics_redraw = common.physics.evaluate(renpy.display.interface.frame_time)

        # Determine when to redraw.
        redraws = [new_redraw, old_redraw, expression_redraw, pose_redraw, user_redraw, physics_redraw]
        redraws = [i for i in redraws if i is not None]

        if redraws:
            renpy.display.render.redraw(self, min(redraws))

        # Get the textures.
        textures = [renpy.display.im.render_for_texture(d, width, height, st, at) for d in common.textures]

        sw, sh = model.get_size()

        zoom = self.zoom

        if zoom is None:
            top = absolute.compute_raw(self.top, sh)
            base = absolute.compute_raw(self.base, sh)

            size = max(base - top, 1.0)

            zoom = 1.0 * self.height * renpy.config.screen_height / size
        else:
            size = sh
            top = 0

        # Render the model.
        rend = model.render(textures, zoom)

        # Apply scaling as needed.
        rv = renpy.exports.Render(sw * zoom, size * zoom)
        rv.blit(rend, (0, -top * zoom))

        return rv

    def visit(self):
        return self.common.textures


# Caches the result of has_live2d.
_has_live2d = None


def has_live2d():
    """
    :doc: live2d

    Returns True if Live2d is supported on the current platform, and
    False otherwise.
    """

    global _has_live2d

    if _has_live2d is None:
        try:
            init()
            _has_live2d = True
        except Exception:
            _has_live2d = False

    return _has_live2d
