# Copyright 2004-2026 Tom Rothamel <pytom@bishoujo.us>
#
# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

# This file contains code that handles the execution of python code
# contained within the script file. It also handles rolling back the
# game state to some time in the past.

# Import the future module itself.
import __future__

# Import the python ast module, not ours.
import ast
import collections
import contextlib
import copyreg
import importlib.util
import marshal
import os
import sys
import types
import warnings
import weakref
import zlib
from typing import Any, Final, Literal

import renpy
from renpy.astsupport import hash64
from renpy.compat.pickle import dumps, loads
from renpy.pydict import DictItems, find_changes

# Import these for pickle-compatibility.
from renpy.revertable import (  # noqa: F401
    CompressedList,
    DetRandom,
    RevertableDict,
    RevertableList,
    RevertableObject,
    RevertableSet,
    RollbackRandom,
    revertable_range,
    revertable_sorted,
)
from renpy.rollback import (  # noqa: F401
    AlwaysRollback,
    NoRollback,
    Rollback,
    RollbackLog,
    SlottedNoRollback,
    StoreDeleted,
    deleted,
    reached,
    reached_vars,
    rng,
)

##############################################################################
# Code that implements the store.


class StoreModule(object):
    """
    This class represents one of the modules containing the store of data.
    """

    # Set our dict to be the StoreDict. Then proxy over setattr and delattr,
    # since Python won't call them by default.

    def __reduce__(self):
        return (get_store_module, (self.__name__,))  # type: ignore

    def __init__(self, d):
        object.__setattr__(self, "__dict__", d)

    def __setattr__(self, key, value):
        self.__dict__[key] = value

    def __delattr__(self, key):
        del self.__dict__[key]


# Used to unpickle a store module.


def get_store_module(name):
    return sys.modules[name]


class StoreDict(dict):
    """
    This class represents the dictionary of a store module. It logs
    sets and deletes.
    """

    def __reduce__(self):
        raise Exception("Cannot pickle a reference to a store dictionary.")

    def __init__(self):
        # The value of this dictionary at the start of the current
        # rollback period (when begin() was last called).
        self.old = DictItems(self)

        # The set of variables in this StoreDict that changed since the
        # end of the init phase.
        self.ever_been_changed = set()

    def reset(self):
        """
        Called to reset this to its initial conditions.
        """

        self.ever_been_changed = set()
        self.clear()
        self.old = DictItems(self)

    def begin(self):
        """
        Called to mark the start of a rollback period.
        """

        if self.get("_constant", False):
            return

        self.old = DictItems(self)

    def get_changes(self, cycle, previous):
        """
        For every key that has changed since begin() was called, returns a
        dictionary mapping the key to its value when begin was called, or
        deleted if it did not exist when begin was called.

        As a side-effect, updates self.ever_been_changed, and returns the
        changes to ever_been_changed as well.

        `cycle`
            If true, this cycles the old changes to the new changes. If
            False, does not.

        `previous`
            The result of a call to this from a previous cycle. The result
            from a previous run take precedence over the current run. None
            if this is the first run.
        """

        if self.get("_constant", False):
            return

        new = DictItems(self)
        rv = find_changes(self.old, new, deleted)

        if rv is None:
            return None

        if cycle:
            self.old = new

        if previous is not None:
            rv.update(previous)

        delta_ebc = set()

        if cycle:
            for k in rv:
                if k not in self.ever_been_changed:
                    self.ever_been_changed.add(k)
                    delta_ebc.add(k)

        return rv, delta_ebc


def begin_stores():
    """
    Calls .begin on every store dict.
    """

    for sd in store_dicts.values():
        sd.begin()


# A map from the name of a store dict to the corresponding StoreDict object.
# This isn't reset during a reload, so store objects stay the same in modules.
store_dicts = {}

# Same, for module objects.
store_modules = {}

# The store dicts that have been cleared and initialized during the current
# run.
initialized_store_dicts = set()


def create_store(name: str):
    """
    Creates the store with `name`.
    """

    if name == "store.store":
        raise NameError('Namespaces may not begin with "store".')

    parent, _, var = name.rpartition(".")

    if parent:
        create_store(parent)
        package = parent
    else:
        package = "store"
        parent = "store"

    if name in initialized_store_dicts:
        return

    initialized_store_dicts.add(name)

    # Create the dict.
    d = store_dicts.setdefault(name, StoreDict())
    d.reset()

    # Set up the contents of a normal module.
    d.update(__name__=name, __package__=package, __loader__=None, __spec__=None, __path__=None)

    # Set up the default contents of the store.
    eval("1", d)

    for k, v in renpy.minstore.__dict__.items():
        if k in ("__all__", "__name__", "__doc__", "__package__", "__loader__", "__spec__", "__file__", "__cached__"):
            continue

        if k in d:
            continue

        d[k] = v

    # Create or reuse the corresponding module.
    if name in store_modules:
        sys.modules[name] = store_modules[name]
    else:
        store_modules[name] = sys.modules[name] = StoreModule(d)  # type: ignore

    if parent:
        store_dicts[parent][var] = sys.modules[name]

        # Make sure the parent is a package. (In the case of store, it's its own parent, so always is a package.)
        store_dicts[parent].update(__path__=[], __package__=parent)


class StoreBackup:
    """
    This creates a copy of the current store, as it was at the start of
    the current statement.
    """

    def __init__(self):
        # The contents of the store for each store.
        self.store = {}

        # The contents of old for each store.
        self.old = {}

        # The contents of ever_been_changed for each store.
        self.ever_been_changed = {}

        for k, v in store_dicts.items():
            if not v.get("_constant", False):
                self.backup_one(k)

    def backup_one(self, name):
        d = store_dicts[name]

        self.store[name] = dict(d)
        self.old[name] = d.old.as_dict()
        self.ever_been_changed[name] = set(d.ever_been_changed)

    def restore_one(self, name):
        sd = store_dicts[name]

        sd.clear()
        sd.update(self.store[name])

        sd.old = DictItems(self.old[name])

        sd.ever_been_changed.clear()
        sd.ever_been_changed.update(self.ever_been_changed[name])

    def restore(self):
        for k in self.store:
            self.restore_one(k)


clean_store_backup: StoreBackup | None = None


def make_clean_stores():
    """
    Copy the clean stores.
    """

    global clean_store_backup

    for _k, v in store_dicts.items():
        v.ever_been_changed.clear()
        v.begin()

    clean_store_backup = StoreBackup()


def clean_stores():
    """
    Revert the store to the clean copy.
    """

    clean_store_backup.restore()


def clean_store(name):
    """
    Reverts the named store to its clean copy.
    """

    if not name.startswith("store."):
        name = "store." + name

    clean_store_backup.restore_one(name)


def reset_store_changes(name):
    if not name.startswith("store."):
        name = "store." + name

    sd = store_dicts[name]
    sd.begin()


def mark_changed(name: str, variable: str):
    """
    :undocumented:

    Marks `variable` in the store with `name` as changed, causing it to be saved/loaded.
    """

    if not name.startswith("store."):
        name = "store." + name

    sd = store_dicts[name]
    sd.ever_been_changed.add(variable)


# Code that replaces literals will calls to magic constructors.
class LoadedVariables(ast.NodeVisitor):
    """
    This is used to implement find_loaded_variables.
    """

    def visit_Name(self, node):
        if isinstance(node.ctx, ast.Load):
            self.loaded.add(node.id)
        elif isinstance(node.ctx, ast.Store):
            self.stored.add(node.id)

    def visit_MatchMapping(self, node):
        if node.rest:
            self.stored.add(node.rest)

    def visit_MatchStar(self, node):
        if node.name is not None:
            self.stored.add(node.name)

    def visit_MatchAs(self, node):
        if node.name is not None:
            self.stored.add(node.name)

    def visit_arg(self, node):
        self.stored.add(node.arg)

    def find(self, node):
        self.loaded = set()
        self.stored = set()

        self.visit(node)

        return self.loaded - self.stored


# Given a comprehension or generator expression, returns the list of variables
# that are loaded from external scopes.
find_loaded_variables = LoadedVariables().find


class StarredVariables(ast.NodeVisitor):
    """
    Return a list of variables that are set using starred assignment, and hence
    need to be wrapped in RevertableList.
    """

    def visit_Starred(self, node):
        if isinstance(node.value, ast.Name) and isinstance(node.value.ctx, ast.Store):
            self.starred.add(node.value.id)

    def visit_Name(self, node):
        if isinstance(node.ctx, ast.Store):
            self.starred.discard(node.id)

    def find(self, targets):
        self.starred = set()

        for i in targets:
            self.visit(i)

        return self.starred


# Given an assignment target list, return a list of variables that are set using
# starred assignment.
find_starred_variables = StarredVariables().find


class FindStarredMatchPatterns(ast.NodeVisitor):
    """
    Given a match patten, return a list of (name, type) tuples, where type is "dict" or "list".
    """

    def __init__(self):
        self.vars = []

    def visit_MatchStar(self, node: ast.MatchStar) -> Any:
        self.generic_visit(node)
        if node.name is not None:
            self.vars.append((node.name, "list"))

    def visit_MatchMapping(self, node: ast.MatchMapping) -> Any:
        self.generic_visit(node)
        if node.rest is not None:
            self.vars.append((node.rest, "dict"))


def find_starred_match_patterns(node):
    """
    Given a match pattern, return a list of (name, type) tuples, where type is "dict" or "list".
    """

    visitor = FindStarredMatchPatterns()
    visitor.visit(node)
    return visitor.vars


class WrapNode(ast.NodeTransformer):
    def __init__(self):
        # Do we call `renpy.pyanalysis.import_from` when importing stuff?
        self.call_import_from = True

    def wrap_generator(self, node):
        """
        This wraps generators in lambdas, such that:

            (i for i in l if i == b)

        becomes:

            (lambda l, b : (i for i in l if i == b))(l, b)

        Why do this? It's because if b is a local, it's not present inside
        the generator expression scope, and when compiled independently of
        a larger scope, no cell is generated.
        """

        variables = list(sorted(find_loaded_variables(node)))

        node = self.generic_visit(node)

        lambda_args = []
        call_args = []

        for var in variables:
            lambda_args.append(ast.arg(arg=var))
            call_args.append(ast.Name(id=var, ctx=ast.Load()))

        return ast.Call(
            func=ast.Lambda(
                args=ast.arguments(
                    posonlyargs=[],
                    args=lambda_args,
                    kwonlyargs=[],
                    kw_defaults=[],
                    defaults=[],
                ),
                body=node,  # type: ignore
            ),
            args=call_args,
            keywords=[],
        )

    def wrap_starred_assign(self, n, targets):
        starred = find_starred_variables(targets)

        if not starred:
            return n

        list_stmts = []

        for var in starred:
            call = ast.Call(
                func=ast.Name(id="__renpy__list__", ctx=ast.Load()),
                args=[ast.Name(id=var, ctx=ast.Load())],
                keywords=[],
            )

            assign = ast.Assign(
                targets=[ast.Name(id=var, ctx=ast.Store())],
                value=call,
            )

            list_stmts.append(assign)

        return ast.Try(
            body=[n],
            handlers=[],
            orelse=[],
            finalbody=list_stmts,
        )

    def wrap_starred_for(self, node):
        starred = find_starred_variables([node.target])

        if not starred:
            return node

        for var in starred:
            call = ast.Call(
                func=ast.Name(id="__renpy__list__", ctx=ast.Load()),
                args=[ast.Name(id=var, ctx=ast.Load())],
                keywords=[],
            )

            assign = ast.Assign(
                targets=[ast.Name(id=var, ctx=ast.Store())],
                value=call,
            )

            node.body.insert(0, assign)

        return node

    def wrap_starred_with(self, node):
        optional_vars = []

        for i in node.items:
            if i.optional_vars is not None:
                optional_vars.append(i.optional_vars)

        if not optional_vars:
            return node

        starred = find_starred_variables(optional_vars)

        if not starred:
            return node

        for var in starred:
            call = ast.Call(
                func=ast.Name(id="__renpy__list__", ctx=ast.Load()),
                args=[ast.Name(id=var, ctx=ast.Load())],
                keywords=[],
            )

            assign = ast.Assign(
                targets=[ast.Name(id=var, ctx=ast.Store())],
                value=call,
            )

            node.body.insert(0, assign)

        return node

    def wrap_match_case(self, node):
        starred = find_starred_match_patterns(node.pattern)
        if not starred:
            return node

        for var, kind in reversed(starred):
            if kind == "list":
                call = ast.Call(
                    func=ast.Name(id="__renpy__list__", ctx=ast.Load()),
                    args=[ast.Name(id=var, ctx=ast.Load())],
                    keywords=[],
                )

                assign = ast.Assign(
                    targets=[ast.Name(id=var, ctx=ast.Store())],
                    value=call,
                )

                node.body.insert(0, assign)

            elif kind == "dict":
                call = ast.Call(
                    func=ast.Name(id="__renpy__dict__", ctx=ast.Load()),
                    args=[ast.Name(id=var, ctx=ast.Load())],
                    keywords=[],
                )

                assign = ast.Assign(
                    targets=[ast.Name(id=var, ctx=ast.Store())],
                    value=call,
                )

                node.body.insert(0, assign)

        return node

    def visit_Assign(self, node: ast.Assign):
        node = self.generic_visit(node)  # type: ignore
        return self.wrap_starred_assign(node, node.targets)

    def visit_AnnAssign(self, node: ast.AnnAssign):
        node = self.generic_visit(node)  # type: ignore
        return self.wrap_starred_assign(node, [node.target])

    def visit_For(self, node):
        node = self.generic_visit(node)
        return self.wrap_starred_for(node)

    def visit_AsyncFor(self, node):
        node = self.generic_visit(node)
        return self.wrap_starred_for(node)

    def visit_With(self, node):
        node = self.generic_visit(node)
        return self.wrap_starred_with(node)

    def visit_AsyncWith(self, node):
        node = self.generic_visit(node)
        return self.wrap_starred_with(node)

    def visit_ClassDef(self, node: ast.ClassDef):
        old = self.call_import_from
        self.call_import_from = False
        node = self.generic_visit(node)  # type: ignore
        self.call_import_from = old

        # This will force the class to inherit from RevertableObject.
        if not node.bases:
            node.bases.append(ast.Name(id="object", ctx=ast.Load()))

        return node

    def visit_GeneratorExp(self, node):
        return self.wrap_generator(node)

    def visit_SetComp(self, node):
        return ast.Call(
            func=ast.Name(id="__renpy__set__", ctx=ast.Load()), args=[self.wrap_generator(node)], keywords=[]
        )

    def visit_Set(self, node):
        return ast.Call(
            func=ast.Name(id="__renpy__set__", ctx=ast.Load()),
            args=[self.generic_visit(node)],  # type: ignore
            keywords=[],
        )

    def visit_ListComp(self, node):
        return ast.Call(
            func=ast.Name(id="__renpy__list__", ctx=ast.Load()), args=[self.wrap_generator(node)], keywords=[]
        )

    def visit_List(self, node):
        if not isinstance(node.ctx, ast.Load):
            return self.generic_visit(node)

        return ast.Call(
            func=ast.Name(id="__renpy__list__", ctx=ast.Load()),
            args=[self.generic_visit(node)],  # type: ignore
            keywords=[],
        )

    def visit_DictComp(self, node):
        return ast.Call(
            func=ast.Name(id="__renpy__dict__", ctx=ast.Load()), args=[self.wrap_generator(node)], keywords=[]
        )

    def visit_Dict(self, node):
        return ast.Call(
            func=ast.Name(id="__renpy__dict__", ctx=ast.Load()),
            args=[self.generic_visit(node)],  # type: ignore
            keywords=[],
        )

    def visit_Match(self, node: ast.Match):
        node = self.generic_visit(node)  # type: ignore
        node.cases = [self.wrap_match_case(i) for i in node.cases]
        return node

    def visit_FunctionDef(self, node):
        old = self.call_import_from
        self.call_import_from = False
        node = self.generic_visit(node)
        self.call_import_from = old

        return node

    def visit_ImportFrom(self, node):
        if not self.call_import_from:
            return node

        namespace = node.module
        if namespace.startswith("store"):
            namespace = namespace[6:]

        names = [(alias.name, alias.asname or alias.name) for alias in node.names]

        if not names:
            return node

        rv: list[ast.AST] = [node]

        args = []

        # name of the module we're importing from
        args.append(ast.Constant(namespace))

        # name of the module we're importing into
        args.append(ast.Name(id="__name__", ctx=ast.Load()))

        # what we are importing
        args.extend([ast.Tuple([ast.Constant(name), ast.Constant(asname)], ctx=ast.Load()) for name, asname in names])

        renpy_pyanalysis_import_from = ast.Attribute(
            value=ast.Attribute(value=ast.Name(id="_renpy_exports", ctx=ast.Load()), attr="pyanalysis", ctx=ast.Load()),
            attr="import_from",
            ctx=ast.Load(),
        )

        rv.append(ast.Expr(value=ast.Call(func=renpy_pyanalysis_import_from, args=args, keywords=[])))

        return rv


wrap_node = WrapNode()


def wrap_hide(tree):
    """
    Wraps code inside a python hide or python early hide block inside a
    function, so it gets its own scope that works the way Python expects
    it to.
    """

    hide = ast.parse("""\
def _execute_python_hide(): pass;
_execute_python_hide()
""")

    for i in ast.walk(hide):
        ast.copy_location(i, hide.body[0])

    hide.body[0].body = tree.body  # type: ignore
    tree.body = hide.body


@contextlib.contextmanager
def save_warnings():
    """
    A context manager that captures warnings issued during compilation.
    """

    pending_warnings: list[tuple[str, int, str]] = []

    def showwarning(message, category, filename, lineno, file=None, line=None):
        pending_warnings.append((filename, lineno, warnings.formatwarning(message, category, filename, lineno, line)))

    old = warnings.showwarning

    try:
        warnings.showwarning = showwarning

        yield pending_warnings

    finally:
        warnings.showwarning = old


type CompileMode = Literal["eval", "exec", "hide"]


class CompileCache:
    """
    This class holds the cache for the results of py_compile.

    This has two levels of cache:
    - The first level is a cache from cache key to the bytecode.
    - The second level is a cache from cache key to marshaled bytecode.

    Second level cache is stored in bytecode.rpyb file, while the first level
    cache is computed from the second level cache for each run.

    Futhermore, each cache is also split into old and new generations that are
    swapped every utter_restart.
    """

    BYTECODE_VERSION = 1
    "The version of the bytecode cache."

    OLD_BYTECODE_FILE: Final = "cache/bytecode.rpyb"
    "The name of bytecode cache file before Ren'Py 8."

    BYTECODE_FILE: Final = f"cache/bytecode-{sys.version_info.major}{sys.version_info.minor}.rpyb"
    "The name of bytecode cache file used to store the bytecode cache."

    # Change this to force a recompile of Python when required.
    MAGIC_NUMBER: Final = importlib.util.MAGIC_NUMBER + b"_2026-08-30"
    "Magic number used to invalidate the bytecode cache that is invalid for the current version of Ren'Py."

    type ItemKey = tuple[
        int,  # hashcode
        int,  # lineno
        str,  # filename
        CompileMode,  # mode
        int,  # flags
        int,  # column
    ]

    type CacheKey = tuple[
        int,  # hashcode
        int,  # lineno
        str,  # filename
        CompileMode,  # mode
        bytes,  # MAGIC_NUMBER
        int,  # flags
        int,  # column
    ]

    type WarningsKey = tuple[Literal["warnings"], CacheKey]

    type LiteralValue = tuple[Literal["literal"], Any]

    def __init__(self):
        self.old_compile_cache: dict[CompileCache.CacheKey, types.CodeType | CompileCache.LiteralValue] = {}
        self.new_compile_cache: dict[CompileCache.CacheKey, types.CodeType | CompileCache.LiteralValue] = {}

        self.old_bytecode_cache: dict[CompileCache.CacheKey, bytes] = {}
        self.new_bytecode_cache: dict[CompileCache.CacheKey, bytes] = {}

        self.warnings: dict[CompileCache.WarningsKey, list[tuple[str, int, str]]] = {}
        "A map of warnings key to a list of (filename, linenumber, warning) tuples generated for that key."

        self.bytecode_dirty = False
        "True if bytecode has been modified and needs to be saved."

    def load(self):
        """
        Loads the bytecode cache.
        """

        if renpy.game.args.compile_python:
            return

        try:
            with renpy.loader.load(CompileCache.BYTECODE_FILE) as f:
                version, cache = loads(zlib.decompress(f.read()))
                if version == CompileCache.BYTECODE_VERSION:
                    self.old_bytecode_cache = {k: v for k, v in cache.items() if k[0] != "warnings"}
                    self.warnings = {k: v for k, v in cache.items() if k[0] == "warnings"}
        except Exception:
            pass

    def save(self):
        """
        Saves the bytecode cache.

        Also drops warnings whose code was not compiled or loaded during this run, so warnings for code that
        has been changed or removed are neither saved nor reported by lint.
        """

        self.warnings = {k: v for k, v in self.warnings.items() if k[1] in self.new_bytecode_cache}

        if renpy.macapp:
            return

        if not self.bytecode_dirty:
            return

        try:
            fn = renpy.loader.get_path(CompileCache.BYTECODE_FILE)

            with open(fn, "wb") as f:
                data = (
                    CompileCache.BYTECODE_VERSION,
                    self.new_bytecode_cache | self.warnings,
                )
                f.write(zlib.compress(dumps(data), 3))
        except Exception:
            pass

        fn = renpy.loader.get_path(CompileCache.OLD_BYTECODE_FILE)
        try:
            os.unlink(fn)
        except Exception:
            pass

    def reload(self):
        self.old_compile_cache = self.new_compile_cache
        self.new_compile_cache = {}

        self.old_bytecode_cache = self.new_bytecode_cache
        self.new_bytecode_cache = {}

        self.bytecode_dirty = True

    def get(self, item_key: ItemKey) -> types.CodeType | LiteralValue | None:
        hashcode, lineno, filename, mode, flags, column = item_key
        key = (hashcode, lineno, filename, mode, CompileCache.MAGIC_NUMBER, flags, column)

        if rv := self.new_compile_cache.get(key):
            return rv

        if rv := self.old_compile_cache.get(key):
            self.new_compile_cache[key] = rv

            if key not in self.new_bytecode_cache:
                self.new_bytecode_cache[key] = marshal.dumps(rv)

            return rv

        if bytecode := self.old_bytecode_cache.get(key):
            try:
                rv = marshal.loads(bytecode)
                self.new_compile_cache[key] = rv
                self.new_bytecode_cache[key] = bytecode

                return rv
            except Exception:
                pass

        return None

    def put(
        self,
        item_key: ItemKey,
        value: types.CodeType | LiteralValue,
        warnings: list[tuple[str, int, str]],
    ):
        hashcode, lineno, filename, mode, flags, column = item_key
        key = (hashcode, lineno, filename, mode, CompileCache.MAGIC_NUMBER, flags, column)

        self.new_compile_cache[key] = value
        self.new_bytecode_cache[key] = marshal.dumps(value)
        if warnings:
            self.warnings["warnings", key] = warnings
        self.bytecode_dirty = True


compile_cache = CompileCache()

# A set of __future__ flag overrides for each file.
file_compiler_flags = collections.defaultdict(int)


class LocationFixer:
    """
    This class is responsible for fixing the locations of nodes in the AST. First,
    it will adjust the line numbers and column offsets, and then it will use this
    information to fill in missing attributes.

    `line_delta`
        The number of lines to add to the line numbers of the nodes.

    `first_line_col_delta`
        The number of columns to add to the column offsets of the first line.

    `rest_line_col_delta`
        The number of columns to add to the column offsets of the rest of the lines.
    """

    line_delta: int
    first_line_col_delta: int
    rest_line_col_delta: int

    def __init__(
        self,
        node: ast.Module | ast.Expression,
        line_delta: int = 0,
        first_line_col_delta: int = 0,
        rest_line_col_delta: int = 0,
    ):
        self.line_delta = line_delta
        self.first_line_col_delta = first_line_col_delta
        self.rest_line_col_delta = rest_line_col_delta

        self.fix(node, 1 + line_delta, first_line_col_delta)

    def fix(self, node: Any, lineno: int, col_offset: int):
        # Not all nodes have location attributes, e.g. expr_context.
        # But it's either none of them, or all 4 of them.
        if "lineno" not in node._attributes:
            for c in ast.iter_child_nodes(node):
                self.fix(c, lineno, col_offset)

            return

        # This finds missing attributes by triggering AttributeErrors if an attribute is missing.
        try:
            if node.lineno == 1:
                node.col_offset += self.first_line_col_delta
            else:
                node.col_offset += self.rest_line_col_delta

            node.lineno += self.line_delta
            lineno, col_offset = node.lineno, node.col_offset

        except (AttributeError, TypeError):
            node.lineno = lineno
            node.col_offset = col_offset

        try:
            if node.end_lineno == 1:
                node.end_col_offset += self.first_line_col_delta
            else:
                node.end_col_offset += self.rest_line_col_delta

            node.end_lineno += self.line_delta

        except (AttributeError, TypeError):
            node.end_lineno = node.lineno
            node.end_col_offset = node.col_offset

        end = (node.end_lineno, node.end_col_offset)
        for c in ast.iter_child_nodes(node):
            self.fix(c, lineno, col_offset)

            # Not all children may have end location attributes.
            if "lineno" in c._attributes:
                end = max(end, (c.end_lineno, c.end_col_offset))  # type: ignore

        node.end_lineno, node.end_col_offset = end


IMMUTABLE_TYPES = (int, float, str, bool, bytes, type(None), complex)


def is_immutable_value(v):
    """
    Returns True if v is an immutable value, and False if it is not.
    """

    if isinstance(v, IMMUTABLE_TYPES):
        return True

    if isinstance(v, tuple):
        return all(is_immutable_value(i) for i in v)

    return False


def py_compile(
    source: "str | bytes | ast.Module",
    mode: CompileMode,
    filename: str = "<none>",
    lineno: int = 1,
    ast_node: bool = False,
    cache: bool = True,
    py: None = None,
    hashcode: int | None = None,
    column: int = 0,
):
    """
    Compiles the given source code using the supplied codegenerator.
    Lists, List Comprehensions, and Dictionaries are wrapped when
    appropriate.

    `source`
        The source code, as a either a string, pyexpr, or ast module
        node.

    `mode`
        One of "eval", "exec", or "hide".

    `filename`
        The filename the source comes from. If a pyexpr is given, the
        filename embedded in the pyexpr is used.

    `lineno`
        The line number of the first line of source code. If a pyexpr is
        given, the filename embedded in the pyexpr is used.

    `ast_node`
        Rather than returning compiled bytecode, returns the AST object
        that would be used.

    `column`
        A column offset to add to the column numbers of the source.
    """

    if isinstance(source, ast.Module):
        return compile(source, filename, mode)
    elif isinstance(source, bytes):
        source = source.decode("utf-8")
    elif not isinstance(source, str):
        raise TypeError("source must be a string, renpy.ast.PyExpr, or ast.Module")

    first_line_column_delta = column
    rest_line_column_delta = column

    if ast_node:
        cache = False

    if isinstance(source, renpy.ast.PyExpr):
        filename = source.filename
        lineno = source.linenumber
        hashcode = source.hashcode

        first_line_column_delta = source.column
        rest_line_column_delta = 0

    if hashcode is None:
        # PyExpr uses hash32, but when filename and line number are not
        # available, e.g. py_eval call, the probability of hash collisions
        # is high enough to warrant using a wider hash function.
        hashcode = hash64(source)

    flags = file_compiler_flags.get(filename, 0)

    if renpy.config.future_annotations:
        flags |= __future__.annotations.compiler_flag

    key: CompileCache.ItemKey = (hashcode, lineno, filename, mode, flags, column)
    if cache and (rv := compile_cache.get(key)):
        return rv

    # This determines if the lines are indented. If so, we adjust the ast to match.
    # This is needed because parsed code could keep the indentation and as is
    # it would raise an IndentationError when compiled.
    if indented := mode != "eval" and source.startswith(" "):
        lineno -= 1
        source = f"if True:\n{source}"

    # In eval mode we need to add explicit line joining so things like
    # foo(param=1 +
    # 2)
    # works.
    elif mode == "eval" and "\n" in source and source.strip():
        lineno -= 1
        source = f"(\n{source}\n)"

    if mode == "eval" and not ast_node:
        # If possible, compute the value of immutable literals.
        try:
            with save_warnings() as warnings:
                rv = ast.literal_eval(source)
                if is_immutable_value(rv):
                    rv = ("literal", rv)
                    compile_cache.put(key, rv, warnings)
                    return rv
        except Exception:
            pass

    line_offset = lineno - 1

    try:
        if mode == "hide":
            py_mode = "exec"
        else:
            py_mode = mode

        tree: Any = None

        with save_warnings() as warnings:
            try:
                tree = compile(source, filename, py_mode, ast.PyCF_ONLY_AST | flags, True)

            except SyntaxError:
                handled = False
                try:
                    fixed_source = renpy.compat.fixes.fix_tokens(source)
                    tree = compile(fixed_source, filename, py_mode, ast.PyCF_ONLY_AST | flags, True)
                    handled = True
                except Exception:
                    pass

                if not handled:
                    raise

            # If the body is indented, it's wrapped in an "if True:" statement, which needs to be eliminated.
            if indented:
                tree.body = tree.body[0].body

            tree = wrap_node.visit(tree)

            if mode == "hide":
                wrap_hide(tree)

            LocationFixer(
                tree,
                lineno - 1,
                first_line_column_delta,
                rest_line_column_delta,
            )

            line_offset = 0

            if ast_node:
                return tree.body

            rv: Any = None
            try:
                rv = compile(tree, filename, py_mode, flags, True)
            except SyntaxError:
                handled = False
                try:
                    tree = renpy.compat.fixes.fix_ast(tree)
                    LocationFixer(tree, 0, 0, 0)
                    rv = compile(tree, filename, py_mode, flags, True)
                    handled = True
                except Exception:
                    pass

                if not handled:
                    raise

        if cache:
            compile_cache.put(key, rv, warnings)

        return rv

    except SyntaxError as e:
        try:
            e.text = source.splitlines()[e.lineno - 1]
        except Exception:
            pass

        if e.lineno is not None:
            e.lineno += line_offset

        raise


def py_exec_bytecode(bytecode, hide=False, globals=None, locals=None, store="store"):
    if hide:
        locals = {}

    if globals is None:
        globals = store_dicts[store]

    if locals is None:
        locals = globals

    exec(bytecode, globals, locals)


def py_exec(source, hide=False, store=None):
    if store is None:
        store = store_dicts["store"]

    if hide:
        locals = {}
    else:
        locals = store

    exec(py_compile(source, "exec"), store, locals)


def py_eval_bytecode(bytecode, globals=None, locals=None):
    if bytecode.__class__ is tuple:
        return bytecode[1]

    if globals is None:
        globals = store_dicts["store"]

    if locals is None:
        locals = globals

    return eval(bytecode, globals, locals)


def py_eval(code, globals=None, locals=None):
    if isinstance(code, str):
        code = py_compile(code, "eval")

    return py_eval_bytecode(code, globals, locals)


def store_eval(code, globals=None, locals=None):
    if globals is None:
        globals = sys._getframe(1).f_globals

    return py_eval(code, globals, locals)


def raise_at_location(e, loc):
    """
    Raises `e` (which must be an Exception object) at location `loc`.

    `loc`
        A location, which should be a (filename, line_number) tuple.
    """

    filename, line = loc

    node = ast.parse("raise e", filename)
    ast.increment_lineno(node, line - 1)
    code = compile(node, filename, "exec")

    exec(code, {"e": e})


# This was used to proxy accesses to the store. Now it's kept around to deal
# with cases where it might have leaked into a pickle.
class StoreProxy(object):
    def __getattr__(self, k):
        return getattr(renpy.store, k)

    def __setattr__(self, k, v):
        setattr(renpy.store, k, v)

    def __delattr__(self, k):
        delattr(renpy.store, k)


# This needs to exist even after PY2 support is dropped, to load older saves.
def method_unpickle(obj, name):
    return getattr(obj, name)


# Code for pickling modules.


def module_pickle(module):
    if renpy.config.developer:
        raise Exception("Could not pickle {!r}.".format(module))

    return module_unpickle, (module.__name__,)


def module_unpickle(name):
    return __import__(name)


copyreg.pickle(types.ModuleType, module_pickle)

# Allow weakrefs to be pickled, with the reference being broken during
# unpickling.


def construct_None(*args):
    return None


def pickle_weakref(r):
    return (construct_None, ())


copyreg.pickle(weakref.ReferenceType, pickle_weakref)
