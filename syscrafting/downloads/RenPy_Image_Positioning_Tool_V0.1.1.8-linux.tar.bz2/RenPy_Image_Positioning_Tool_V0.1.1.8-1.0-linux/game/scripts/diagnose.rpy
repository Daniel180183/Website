
init -999 python:

    import os
    import ctypes

    sdk_path = "/home/daniel/Daten/RenPy/renpy-8.6.1-sdk_27112026"

    project_path = (
        sdk_path + "/RenPy_Image_Positioning_Tool_V0.1.1.8"
    )

    renpython_path = (
        sdk_path + "/lib/py3-linux-x86_64/librenpython.so"
    )

    diagnose_file = os.path.join(
        project_path,
        "python_diagnose.txt"
    )

    symbols = [
        "PyExc_RuntimeError",
        "PyExc_OSError",
        "PyExc_OverflowError",
        "PyExc_TypeError",
        "PyExc_ValueError"
    ]

    with open(diagnose_file, "w") as f:

        f.write("===== TEST 1: LAUFENDER PROZESS =====\n")

        try:
            process = ctypes.CDLL(None)

            for symbol in symbols:

                try:
                    getattr(process, symbol)
                    f.write(symbol + ": VORHANDEN\n")

                except AttributeError:
                    f.write(symbol + ": NICHT GEFUNDEN\n")

        except Exception as e:
            f.write("Fehler: " + str(e) + "\n")

        f.write("\n===== TEST 2: LIBRENPYTHON.SO =====\n")

        try:
            library = ctypes.CDLL(renpython_path)

            for symbol in symbols:

                try:
                    getattr(library, symbol)
                    f.write(symbol + ": VORHANDEN\n")

                except AttributeError:
                    f.write(symbol + ": NICHT GEFUNDEN\n")

        except Exception as e:
            f.write("Fehler: " + str(e) + "\n")

        f.write("\n===== TEST 3: GELADENE BIBLIOTHEKEN =====\n")

        try:
            with open("/proc/self/maps", "r") as maps:

                for line in maps:

                    if ".so" in line:
                        f.write(line)

        except Exception as e:
            f.write("Fehler: " + str(e) + "\n")
