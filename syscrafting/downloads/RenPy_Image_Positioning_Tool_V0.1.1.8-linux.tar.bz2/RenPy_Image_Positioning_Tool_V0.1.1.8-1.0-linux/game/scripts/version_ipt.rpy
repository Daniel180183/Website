
init -2:
    $ project_name = "Image Positioning Tool"
    $ project_version = "0.1.1.8"
    $ project_name_color = "color=#3aff9240"
