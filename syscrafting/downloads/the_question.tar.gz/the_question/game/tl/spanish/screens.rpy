﻿
translate spanish strings:

    # screens.rpy:251
    old "Back"
    new "Atrás"

    # screens.rpy:252
    old "History"
    new "Historial"

    # screens.rpy:253
    old "Skip"
    new "Saltar"

    # screens.rpy:254
    old "Auto"
    new "Auto"

    # screens.rpy:255
    old "Save"
    new "Guardar"

    # screens.rpy:256
    old "Q.Save"
    new "Guardar R."

    # screens.rpy:257
    old "Q.Load"
    new "Cargar R."

    # screens.rpy:258
    old "Prefs"
    new "Prefs."

    # screens.rpy:299
    old "Start"
    new "Comenzar"

    # screens.rpy:307
    old "Load"
    new "Cargar"

    # screens.rpy:309
    old "Preferences"
    new "Opciones"

    # screens.rpy:313
    old "End Replay"
    new "Finaliza repetición"

    # screens.rpy:317
    old "Main Menu"
    new "Menú principal"

    # screens.rpy:319
    old "About"
    new "Acerca de"

    # screens.rpy:324
    old "Help"
    new "Ayuda"

    # screens.rpy:327
    old "Quit"
    new "Salir"

    # screens.rpy:467
    old "Return"
    new "Regresar"

    # screens.rpy:551
    old "[config.version!t]\n"
    new "[config.version!t]\n"

    # screens.rpy:555
    old "Updated Character Art"
    new "Nuevo arte de personajes"

    # screens.rpy:556
    old "Deji"
    new "Deji"

    # screens.rpy:560
    old "Original Character Art"
    new "Arte de personajes original"

    # screens.rpy:561
    old "Derik"
    new "Derik"

    # screens.rpy:567
    old "Updated Background Art"
    new "Nuevo arte de fondos"

    # screens.rpy:568
    old "Mugenjohncel"
    new "Mugenjohncel"

    # screens.rpy:572
    old "Original Background Art"
    new "Arte de fondos original"

    # screens.rpy:573
    old "DaFool"
    new "DaFool"

    # screens.rpy:579
    old "Music By"
    new "Música"

    # screens.rpy:580
    old "Alessio"
    new "Alessio"

    # screens.rpy:586
    old "Update Written By"
    new "Nuevo Guión"

    # screens.rpy:587
    old "Lore"
    new "Lore"

    # screens.rpy:591
    old "Originally Written By "
    new "Guión Original"

    # screens.rpy:592
    old "mikey (ATP Projects)"
    new "mikey (ATP Projects)"

    # screens.rpy:595
    old "\nMade with {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only]"
    new "\nHecho con {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only]"

    # screens.rpy:597
    old "[renpy.license!t]"
    new "[renpy.license!t]"

    # screens.rpy:643
    old "Page {}"
    new "Página {}"

    # screens.rpy:643
    old "Automatic saves"
    new "Guardado automático"

    # screens.rpy:643
    old "Quick saves"
    new "Guardado rápido"

    # screens.rpy:685
    old "{#file_time}%A, %B %d %Y, %H:%M"
    new "{#file_time}%A, %d de %B %Y, %H:%M"

    # screens.rpy:685
    old "empty slot"
    new "ranura vacía"

    # screens.rpy:702
    old "<"
    new "<"

    # screens.rpy:705
    old "{#auto_page}A"
    new "{#auto_page}A"

    # screens.rpy:708
    old "{#quick_page}Q"
    new "{#quick_page}R"

    # screens.rpy:714
    old ">"
    new ">"

    # screens.rpy:776
    old "Display"
    new "Pantalla"

    # screens.rpy:777
    old "Window"
    new "Ventana"

    # screens.rpy:778
    old "Fullscreen"
    new "Pant. completa"

    # screens.rpy:782
    old "Rollback Side"
    new "Lado de retroceso"

    # screens.rpy:783
    old "Disable"
    new "Desactivar"

    # screens.rpy:784
    old "Left"
    new "Izquierda"

    # screens.rpy:785
    old "Right"
    new "Derecha"

    # screens.rpy:790
    old "Unseen Text"
    new "Texto no visto"

    # screens.rpy:791
    old "After Choices"
    new "Después de las elecciones"

    # screens.rpy:792
    old "Transitions"
    new "Transiciones"

    # screens.rpy:800
    old "Language"
    new "Idioma"

    # screens.rpy:820
    old "Text Speed"
    new "Veloc. texto"

    # screens.rpy:824
    old "Auto-Forward Time"
    new "Veloc. avance automático"

    # screens.rpy:831
    old "Music Volume"
    new "Volumen música"

    # screens.rpy:838
    old "Sound Volume"
    new "Volumen sonido"

    # screens.rpy:844
    old "Test"
    new "Prueba"

    # screens.rpy:848
    old "Voice Volume"
    new "Volumen voz"

    # screens.rpy:859
    old "Mute All"
    new "Silenciar todo"

    # screens.rpy:978
    old "The dialogue history is empty."
    new "El historial está vacío."

    # screens.rpy:1044
    old "Keyboard"
    new "Teclado"

    # screens.rpy:1045
    old "Mouse"
    new "Ratón"

    # screens.rpy:1048
    old "Gamepad"
    new "Mando"

    # screens.rpy:1061
    old "Enter"
    new "Intro"

    # screens.rpy:1062
    old "Advances dialogue and activates the interface."
    new "Avanza el diálogo y activa la interfaz."

    # screens.rpy:1065
    old "Space"
    new "Espacio"

    # screens.rpy:1066
    old "Advances dialogue without selecting choices."
    new "Avanza el diálogo sin seleccionar opciones."

    # screens.rpy:1069
    old "Arrow Keys"
    new "Teclas de flecha"

    # screens.rpy:1070
    old "Navigate the interface."
    new "Navega la interfaz."

    # screens.rpy:1073
    old "Escape"
    new "Escape"

    # screens.rpy:1074
    old "Accesses the game menu."
    new "Accede al menú del juego."

    # screens.rpy:1077
    old "Ctrl"
    new "Ctrl"

    # screens.rpy:1078
    old "Skips dialogue while held down."
    new "Salta el diálogo mientras se mantiene presionado."

    # screens.rpy:1081
    old "Tab"
    new "Tabulador"

    # screens.rpy:1082
    old "Toggles dialogue skipping."
    new "Activa/desactiva el salto de diálogo."

    # screens.rpy:1085
    old "Page Up"
    new "Av. pág."

    # screens.rpy:1086
    old "Rolls back to earlier dialogue."
    new "Retrocede al diálogo anterior."

    # screens.rpy:1089
    old "Page Down"
    new "Re. pág."

    # screens.rpy:1090
    old "Rolls forward to later dialogue."
    new "Avanza hacia el diálogo siguiente."

    # screens.rpy:1094
    old "Hides the user interface."
    new "Oculta la interfaz."

    # screens.rpy:1098
    old "Takes a screenshot."
    new "Captura la pantalla."

    # screens.rpy:1102
    old "Toggles assistive {a=https://www.renpy.org/l/voicing}self-voicing{/a}."
    new "Activa/desactiva la asistencia de {a=https://www.renpy.org/l/voicing}voz automática{/a}."

    # screens.rpy:1108
    old "Left Click"
    new "Clic izquierdo"

    # screens.rpy:1112
    old "Middle Click"
    new "Clic medio"

    # screens.rpy:1116
    old "Right Click"
    new "Clic derecho"

    # screens.rpy:1120
    old "Mouse Wheel Up"
    new "Rueda del ratón arriba"

    # screens.rpy:1124
    old "Mouse Wheel Down"
    new "Rueda del ratón abajo"

    # screens.rpy:1131
    old "Right Trigger\nA/Bottom Button"
    new "Gatillo derecho\nA/Botón inferior"

    # screens.rpy:1135
    old "Left Trigger\nLeft Shoulder"
    new "Gatillo izquierdo\nBotón sup. frontal izq."

    # screens.rpy:1139
    old "Right Shoulder"
    new "Botón sup. frontal der."

    # screens.rpy:1143
    old "D-Pad, Sticks"
    new "D-Pad, Sticks"

    # screens.rpy:1147
    old "Start, Guide"
    new "Start, Guía"

    # screens.rpy:1151
    old "Y/Top Button"
    new "Y/Botón superior"

    # screens.rpy:1154
    old "Calibrate"
    new "Calibrar"

    # screens.rpy:1219
    old "Yes"
    new "Sí"

    # screens.rpy:1220
    old "No"
    new "No"

    # screens.rpy:1266
    old "Skipping"
    new "Saltando"

    # screens.rpy:1487
    old "Menu"
    new "Menú"

    # game/screens.rpy:1108
    old "Opens the accessibility menu."
    new "Abre el menú de accesibilidad."

translate spanish strings:

    # game/screens.rpy:802
    old " "
    new " "

